package parsing;

import java.util.List;

import objects.School;

public class Startparsing {

	private List<School> schools = null;

	public List<School> getSchools() {
	return schools;
	}

	public void setSchools(List<School> schools) {
	this.schools = schools;
	}

}
