package objects;

import java.util.List;

public class Program {

	private List<File> files = null;

	public List<File> getFiles() {
	return files;
	}

	public void setFiles(List<File> files) {
	this.files = files;
	}

}
