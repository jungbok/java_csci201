package objects;

public class TimePeriod {
	private String day;
	private Time time;

	public String getDay() {
		return day;
	}

	public Time getTime() {
		return time;
	}
}
