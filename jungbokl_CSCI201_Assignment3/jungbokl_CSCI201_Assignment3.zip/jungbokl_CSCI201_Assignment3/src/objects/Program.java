package objects;

import java.util.List;

public class Program {
	private List<File> files;

	public List<File> getFiles() {
		return files;
	}
}
