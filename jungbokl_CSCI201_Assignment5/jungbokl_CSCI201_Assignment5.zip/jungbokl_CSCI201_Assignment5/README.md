Name:JungBok Lee
ID number: 6896785721
Email:jungbokl@usc.edu
Lecture Section: Tuesday/Thursday 11:00a.m.-12:20p.m.

zip file is included in the directory
Object package contains all the objects
parsing package contains Json parsing
servlets package contains servlet
jsp files for assignments, exams, lectures, and hompage, css files


properly loads data to mysql
sorting is not done by query
