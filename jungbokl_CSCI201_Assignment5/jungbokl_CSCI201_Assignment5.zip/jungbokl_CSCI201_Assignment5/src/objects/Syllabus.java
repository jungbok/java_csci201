package objects;

public class Syllabus {
	private String url;
	
	public void setUrl(String Url) {
		this.url = Url;
	}

	public String getUrl() {
		return url;
	}
}
