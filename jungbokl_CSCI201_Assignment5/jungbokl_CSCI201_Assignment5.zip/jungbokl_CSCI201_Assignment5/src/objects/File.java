package objects;

//file inherits from GeneralObject because labs have the exact same member variables
public class File extends GeneralObject{
}
