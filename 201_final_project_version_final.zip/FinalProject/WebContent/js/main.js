var buildings = 
		{
		'lyon': new Building('Lyon Center',500000,40,10,10),
		'heritage': new Building('Heritage Hall',600000,40,10,10),
		'village': new Building('Village',5000000,20,20,20),
		'taper': new Building('THH',1000000,10,30,20),
		'leavey': new Building('Leavey Library',2000000,10,40,10),

		'cromwell': new Building('Cromwell Track and Field',200000,40,10,10),
		'annenberg': new Building('Annenberg Building', 3000000,20,20,20),
		'ped': new Building('PED',500000,40,10,10),
		'wph': new Building('WPH',300000,20,20,20),
		'bovard': new Building('Bovard Auditorium',2000000,10,40,10),

		'kap': new Building('KAP',200000,20,20,20),
		'rth': new Building('RTH',300000,20,20,20),
		'miller': new Building('Miller\'s Office',10000000,100,100,100),
		'bookstore': new Building('USC Bookstore',700000,10,10,40),
		'tommy': new Building('Tommy Trojan',1000000,20,20,20),

		'parkside': new Building('Parkside',3000000,20,20,20),
		'sal': new Building('SAL',10000000,10,10,10),
		'coliseum': new Building('Coliseum',7000000,0,60,0),
		'tcc': new Building('TCC',3000000,20,20,20),
		'fertitta': new Building('Fertitta Hall',2000000,20,10,30)
		}

function getLinks(){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (xhttp.responseText.length > 0){
			document.getElementById("links").innerHTML = xhttp.responseText;
		}
	};

	xhttp.open("GET", ctx+"/Links", true);
	xhttp.send();
}
function getTitle()
{
	
	}

function whichElement(e)
{
	var targ;
    if (!e) {
        var e = window.event;
    }
    if (e.target) {
        targ=e.target;
    } else if (e.srcElement) {
        targ=e.srcElement;
    }
    var tname;
    tname = targ.id;
    var building = buildings[tname];
    alert('Name: ' + building.name + 
    		'\nPrice: ' + building.price + 
    		'\nPhysical: ' + building.physical + 
    		'\nIntellectual: ' + building.intellectual + 
    		'\nMonetary: ' + building.monetary);
}

function Building(name, price, physical, intellectual, monetary){
	this.name = name;
	this.price = price;
	this.physical = physical;
	this.intellectual = intellectual;
	this.monetary = monetary;
}

function myFunction() {
    alert("I am an alert box!");
}