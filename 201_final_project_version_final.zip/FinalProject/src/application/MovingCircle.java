package application;
// Alexa Huerta
// ITP 368, Fall 2017
// Assignment 09
// alexahue@usc.edu
// October 29, 2017

import javafx.application.Application;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;

public class MovingCircle extends Circle {
	private double speed = 1.0;

	/**
	 * @param centerX
	 * @param centerY
	 * @param radius
	 * @param fill
	 * @param speed
	 */
	public MovingCircle(double centerX, double centerY, double radius, Paint fill, double speed) {
		super(centerX, centerY, radius, fill);
		this.speed = speed;
		
	}
	

	public void changeDirection(){
		speed *= -1;
	}
	
	public void update(){
		this.setCenterY(this.getCenterY() + speed);
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	
}
