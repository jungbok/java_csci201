package application;

import java.util.ResourceBundle;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class OpenScene {
	
	private ComboBox<Integer> cb = new ComboBox<>();
	private Stage primaryStage;
	private final BorderPane rootPane;
	private ResourceBundle me;
	
	public OpenScene(Stage primaryStage, ResourceBundle me) {
		this.primaryStage = primaryStage;
		this.me = me;
		rootPane = new BorderPane();
		createUIcomponents(rootPane);
		Scene scene = new Scene(rootPane, 700, 450);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	private void createUIcomponents(BorderPane root) {
		Pane topPane = createTopPane();
		topPane.setPrefHeight(150);
		root.setTop(topPane);
		
		Pane centerPane = createCenterPane();
		centerPane.setPrefHeight(150);
		root.setCenter(centerPane);
		
		Pane bottomPane = createBottomPane();
		bottomPane.setPrefHeight(150);
		root.setBottom(bottomPane);
	}
	
	private VBox createTopPane() {
		VBox box = new VBox();
		Label gameTitle = new Label(me.getString("LightsOut.title"));
		gameTitle.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 60));
		gameTitle.setTextFill(Color.YELLOW);
		gameTitle.setTextAlignment(TextAlignment.CENTER);
		gameTitle.setAlignment(Pos.CENTER);
		box.setStyle("-fx-background-color: black;");
		box.getChildren().add(gameTitle);
		box.setAlignment(Pos.CENTER);
		return box;
	}
	
	private HBox createCenterPane() {
		HBox center = new HBox();
		Label select = new Label(me.getString("LightsOut.select"));
		select.setAlignment(Pos.CENTER);
		select.setTextFill(Color.WHITE);
		select.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 20));
		cb.getItems().addAll(3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
		center.setStyle("-fx-background-color: black;");
		center.getChildren().addAll(select, cb);
		center.setAlignment(Pos.CENTER);
		return center;
	}
	
	private HBox createBottomPane() {
		HBox box = new HBox();
		Button play = new Button(me.getString("LightsOut.play"));
		play.setAlignment(Pos.CENTER);
		play.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 30));
		play.setStyle("-fx-background-color: yellow;");
		play.setOnAction(e -> {
			int numLights = cb.getValue();
			GamePortion game = new GamePortion(numLights, primaryStage, me);
			primaryStage.setScene(new Scene(game.getRootPane()));
		});
		box.setStyle("-fx-background-color: black;");
		box.getChildren().add(play);
		box.setAlignment(Pos.CENTER);
		return box;
	}
	
	public Pane getRootPane() {
		return rootPane;
	}
}
