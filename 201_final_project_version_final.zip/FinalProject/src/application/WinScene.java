package application;

import java.util.Random;
import java.util.ResourceBundle;

import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

public class WinScene {
	private final BorderPane rootPane;
	private Stage primaryStage;
	private Pane centerPane;
	private Pane topPane;
	private MovingCircle[] circles;
	private Color[] colors = {Color.BLUE, Color.RED, Color.YELLOW,
			Color.PINK, Color.GREEN };
	private final double RADIUS = 10;
	private MovingCircle a;
	private MovingCircle b;
	private MovingCircle c;
	private MovingCircle d;
	private MovingCircle e;
	private MovingCircle f;
	private MovingCircle g;
	private MovingCircle h;
	private MovingCircle i;
	private MovingCircle j;
	private MovingCircle k;
	private ResourceBundle me;
	
	
	public WinScene(Stage primaryStage, ResourceBundle me) {
		this.primaryStage = primaryStage;
		this.me = me;
		rootPane = new BorderPane();
		centerPane = createCenterPane(new Pane());
		topPane = createTopPane();
		rootPane.setTop(topPane);
		rootPane.setCenter(centerPane);
		rootPane.setPrefHeight(500);
		rootPane.setPrefWidth(500);
		doAnimation();
	}
	
	public Pane getRootPane() {
		return rootPane;
	}
	
	public VBox createTopPane() {
		VBox box = new VBox(5);
		Label congrats = new Label(me.getString("LightsOut.congrats"));
		congrats.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 40));
		congrats.setTextFill(Color.YELLOW);
		Label win = new Label(me.getString("LightsOut.win"));
		win.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 30));
		win.setTextFill(Color.YELLOW);
		Button play = new Button(me.getString("LightsOut.again"));
		play.setStyle("-fx-background-color: yellow;");
		play.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 20));
		play.setOnAction(e -> {
			OpenScene os = new OpenScene(primaryStage, me);
		});
		box.getChildren().addAll(congrats, win, play);
		box.setAlignment(Pos.CENTER);
		box.setStyle("-fx-background-color: black;");
		return box;
	}
	
	public Pane createCenterPane(Pane center) {
		center.setStyle("-fx-background-color: black;");
			a = new MovingCircle(40, 10, RADIUS, colors[0], new Random().nextInt(2)+.5);
			center.getChildren().add(a);
			b = new MovingCircle(80, 10, RADIUS, colors[1], new Random().nextInt(2)+2);
			center.getChildren().add(b);
			c = new MovingCircle(120, 10, RADIUS, colors[2], new Random().nextInt(2)+.2);
			center.getChildren().add(c);
			d = new MovingCircle(160, 10, RADIUS, colors[3], new Random().nextInt(2)+.8);
			center.getChildren().add(d);
			e = new MovingCircle(200, 10, RADIUS, colors[4], new Random().nextInt(2)+.7);
			center.getChildren().add(e);
			f = new MovingCircle(240, 10, RADIUS, colors[0], new Random().nextInt(2)+.4);
			center.getChildren().add(f);
			g = new MovingCircle(280, 10, RADIUS, colors[1], new Random().nextInt(2)+1);
			center.getChildren().add(g);
			h = new MovingCircle(320, 10, RADIUS, colors[2], new Random().nextInt(2)+.3);
			center.getChildren().add(h);
			i = new MovingCircle(360, 10, RADIUS, colors[3], new Random().nextInt(2)+.4);
			center.getChildren().add(i);
			j = new MovingCircle(400, 10, RADIUS, colors[4], new Random().nextInt(2)+.9);
			center.getChildren().add(j);
			k = new MovingCircle(440, 10, RADIUS, colors[0], new Random().nextInt(2)+.6);
			center.getChildren().add(k);
		
		return center;
	}
	
	private void doAnimation() {
		AnimationTimer m = new AnimationTimer(){
			@Override
			public void handle(long now) {
				double windowHeight = centerPane.getHeight();
				moveCircle(a, windowHeight);
				a.update();
				moveCircle(b, windowHeight);
				b.update();
				moveCircle(c, windowHeight);
				c.update();
				moveCircle(d, windowHeight);
				d.update();
				moveCircle(e, windowHeight);
				e.update();
				moveCircle(f, windowHeight);
				f.update();
				moveCircle(g, windowHeight);
				g.update();
				moveCircle(h, windowHeight);
				h.update();
				moveCircle(i, windowHeight);
				i.update();
				moveCircle(j, windowHeight);
				j.update();
				moveCircle(k, windowHeight);
				k.update();
			}

			private void moveCircle(MovingCircle c, double paneHeight) {
				double top = c.getCenterY() - RADIUS;
				double bottom = c.getCenterY() + RADIUS;
				if ( top < 0 ) {
					c.setSpeed( c.getSpeed() * -1 );
				}
			}

		};

		m.start();

	}
}
