package application;

import java.util.Random;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class GamePortion {
	
	private final BorderPane rootPane;
	private int numLights;
	private Light[] lights;
	private Pane centerPane;
	private Stage primaryStage;
	private boolean won;
	private ResourceBundle me;
	
	public GamePortion(int numLights, Stage primaryStage, ResourceBundle me) {
		this.won = false;
		this.me = me;
		this.primaryStage = primaryStage;
		this.numLights = numLights;
		this.lights = new Light[numLights];
		Random r = new Random();
		int horizontal = 50;
		int vertical = 50;
		for(int i=0; i<numLights; i++) {
			Rectangle light = new Rectangle(horizontal*i, vertical*i, horizontal, vertical);
			light.setStroke(Color.BLACK);
			lights[i] = new Light(light, i, r.nextBoolean());
		}
		for(int i=0; i<numLights; i++) {
			int id = lights[i].getId();
			lights[id].getRect().setOnMouseClicked(new EventHandler<MouseEvent>()
	        {
	            @Override
	            public void handle(MouseEvent t) {
	                lights[id].setOn(!lights[id].isOn());
	                if(id == 0) {
	                		lights[id+1].setOn(!lights[id+1].isOn());
	                }
	                else if(id == numLights-1) {
	                		lights[id-1].setOn(!lights[id-1].isOn());
	                }
	                else {
	                		lights[id+1].setOn(!lights[id+1].isOn());
	                		lights[id-1].setOn(!lights[id-1].isOn());
	                }
	                win();
	            }
	        });
		}
		rootPane = new BorderPane();
		createUIcomponents(rootPane);
	}
	
	public Pane getRootPane() {
		return rootPane;
	}
	
	public void win() {
		boolean won = true;
		for(int i=0; i<numLights; i++) {
			if(lights[i].isOn()) {
				won = false;
			}
		}
		if(won == true) {
			WinScene ws = new WinScene(primaryStage, me);
			primaryStage.setScene(new Scene(ws.getRootPane()));
		}
	}
	
	public void createUIcomponents(BorderPane root) {
		Pane topPane = createTopPane();
		topPane.setPrefHeight(150);
		root.setTop(topPane);
		
		centerPane = createCenterPane();
		centerPane.setPrefHeight(150);
		root.setCenter(centerPane);
		
		Pane bottomPane = createBottomPane();
		bottomPane.setPrefHeight(100);
		root.setBottom(bottomPane);
		
	}
	
	private VBox createTopPane() {
		VBox box = new VBox(5);
		Label gameTitle = new Label(me.getString("LightsOut.title"));
		gameTitle.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 60));
		gameTitle.setTextFill(Color.YELLOW);
		gameTitle.setTextAlignment(TextAlignment.CENTER);
		gameTitle.setAlignment(Pos.CENTER);
		Button help = new Button(me.getString("LightsOut.help"));
		help.setFont(Font.font ("Comic Sans MS", 15));
		help.setTextFill(Color.WHITE);
		help.setStyle("-fx-background-color: grey;");
		help.setOnAction(e -> {
			PopUp popup = new PopUp();
			Stage newStage = new Stage();
			newStage.setScene(new Scene(popup.getRootPane(), 500, 400));
			newStage.show();
		});
		box.setStyle("-fx-background-color: black;");
		box.getChildren().addAll(gameTitle, help);
		box.setAlignment(Pos.CENTER);
		return box;
	}
	
	private HBox createCenterPane() {
		HBox center = new HBox();
		for(int i=0; i<numLights; i++) {
			center.getChildren().add(lights[i].getRect());
		}
		center.setAlignment(Pos.CENTER);
		center.setStyle("-fx-background-color: black;");
		return center;
	}
	
	private HBox createBottomPane() {
		HBox box = new HBox(5);
		Button reset = new Button(me.getString("LightsOut.reset"));
		reset.setAlignment(Pos.CENTER);
		reset.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 15));
		reset.setStyle("-fx-background-color: yellow;");
		reset.setOnAction(e -> {
			GamePortion game = new GamePortion(numLights, primaryStage, me);
			primaryStage.setScene(new Scene(game.getRootPane()));
		});
		box.setStyle("-fx-background-color: black;");
		box.getChildren().addAll(reset);
		box.setAlignment(Pos.CENTER);
		return box;
	}
}
