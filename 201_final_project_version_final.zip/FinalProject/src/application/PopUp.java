package application;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class PopUp {
	private final BorderPane rootPane;
	
	public PopUp() {
		rootPane = new BorderPane();
		VBox centerPane = new VBox(5);
		Label instructions = new Label("Click the light you want to switch on or off.");
		Label reaction = new Label("Changing status of a light also switches the neighboring lights.");
		Label goal = new Label("The goal is to turn off all lights.");
		Label reset = new Label("If you want to restart the game, you can hit reset.");
		centerPane.getChildren().addAll(instructions, reaction, goal, reset);
		centerPane.setAlignment(Pos.CENTER);
		rootPane.setCenter(centerPane);
	}
	
	public Pane getRootPane() {
		return rootPane;
	}
}
