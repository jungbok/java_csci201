package application;
	
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;


public class Main extends Application {
	
	private ComboBox<Integer> cb = new ComboBox<>();
	private Stage primaryStage;
	private Locale currentLocale;
	private ResourceBundle me;
	
	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
		try {
			BorderPane root = new BorderPane();
			createUIcomponents(root);
			Scene scene = new Scene(root, 500, 450);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main() {
		launch();
	}
	
	private void createUIcomponents(BorderPane root) {
		
		Pane centerPane = createCenterPane();
		centerPane.setPrefHeight(150);
		root.setCenter(centerPane);
	}
	
	private HBox createCenterPane() {
		HBox center = new HBox(5);
		Button english = new Button("English");
		english.setAlignment(Pos.CENTER);
		english.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 30));
		english.setStyle("-fx-background-color: yellow;");
		english.setOnAction(e -> {
			String language = new String("en");
            String country = new String("US");
            currentLocale = new Locale(language, country);
            me = ResourceBundle.getBundle("messages", currentLocale);
            OpenScene os = new OpenScene(primaryStage, me);
		});
		
		Button spanish = new Button("Espa�ol");
		spanish.setAlignment(Pos.CENTER);
		spanish.setFont(Font.font ("Comic Sans MS", FontWeight.BOLD, 30));
		spanish.setStyle("-fx-background-color: yellow;");
		spanish.setOnAction(e -> {
			String language = new String("es");
            String country = new String("ESP");
            currentLocale = new Locale(language, country);
            me = ResourceBundle.getBundle("messages", currentLocale);
            OpenScene os = new OpenScene(primaryStage, me);
		});
		
		center.setStyle("-fx-background-color: black;");
		center.getChildren().addAll(english, spanish);
		center.setAlignment(Pos.CENTER);
		return center;
		
	}

}
