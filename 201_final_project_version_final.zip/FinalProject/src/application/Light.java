package application;

import java.util.HashMap;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

public class Light {

	private Rectangle rect;
	private int id;
	private boolean on;
	
	public Light(Rectangle rect, int id, boolean on) {
		super();
		this.rect = rect;
		this.id = id;
		this.on = on;
		if(on) {
			rect.setFill(Color.RED);
		}
		else {
			rect.setFill(Color.GREEN);
		}
	}

	public Rectangle getRect() {
		return rect;
	}

	public int getId() {
		return id;
	}

	public boolean isOn() {
		return on;
	}

	public void setOn(boolean on) {
		this.on = on;
		if(on) {
			rect.setFill(Color.RED);
		}
		else {
			rect.setFill(Color.GREEN);
		}
	}
	
}