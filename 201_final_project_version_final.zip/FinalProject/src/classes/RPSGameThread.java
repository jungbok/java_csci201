package classes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

public class RPSGameThread extends Thread{
		
		private PrintWriter print;
		String message;
		RPSGame game;
		boolean signal = false;
		
	public RPSGameThread(PrintWriter pw, RPSGame g)
	{
		game = g;
		print = pw;
		game.addPlayer(this);
		this.start();
	}
		
	public void setWriter(PrintWriter pw)
	{
		print= pw;
	}
		
	public void run()
	{
		while(!signal)
		{
			Thread.yield();
			signal();
			if(game.isDone())
			{
				return;
			}
		}
	}
		
	public void sendMessage(String message) {
		print.write(message);
		print.flush();
	}
	
	public void signal()
	{
		signal = !signal;
	}
}
