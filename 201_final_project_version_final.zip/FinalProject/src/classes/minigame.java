package classes;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import application.*;
import javafx.application.Application;
import javafx.stage.Stage;

@WebServlet("/minigame")
public class minigame extends Application {
	private static final long serialVersionUID = 1L;
       
    public minigame() {
        super();
        System.out.println("here2");
        Main.main();
    }

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
