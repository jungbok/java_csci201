package classes;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

public class User {
	private int id;
	private String username;
	private double money;
	private double power;
	private double intelligence;
	private double totalSkill;
	private boolean isGuest;
	private ArrayList<Building> buildings;
	private ArrayList<Sports> sports;
	private HashMap<String, Integer> ownedBuildings;
	private HashMap<String, Integer> ownedSports;
	
	public User(String username, double money, double power, double intelligence, double totalSkill,
			boolean isGuest) {
		this.username = username;
		this.money = money;
		this.power = power;
		this.intelligence = intelligence;
		this.totalSkill = totalSkill;
		this.isGuest = isGuest;
		this.buildings = new ArrayList<Building>();
		this.sports = new ArrayList<Sports>();
		this.ownedBuildings = new HashMap<String, Integer>();
		this.ownedSports = new HashMap<String, Integer>();	
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public double getIntelligence() {
		return intelligence;
	}
	public void setIntelligence(double intelligence) {
		this.intelligence = intelligence;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public double getPower() {
		return power;
	}
	public void setPower(double power) {
		this.power = power;
	}
	public double getTotalSkill() {
		return totalSkill;
	}
	public void setTotalSkill(double totalSkill) {
		this.totalSkill = totalSkill;
	}
	public boolean isGuest() {
		return isGuest;
	}
	public void setGuest(boolean isGuest) {
		this.isGuest = isGuest;
	}
	public List<Building> getBuildings() {
		return buildings;
	}
	public void setBuildings(ArrayList<Building> buildings) {
		this.buildings = buildings;
	}
	public List<Sports> getSports() {
		return sports;
	}
	public void setSports(ArrayList<Sports> sports) {
		this.sports = sports;
	}
	public HashMap<String, Integer> getOwnedBuildings() {
		return ownedBuildings;
	}
	public void setOwnedBuildings(HashMap<String, Integer> ownedBuildings) {
		this.ownedBuildings = ownedBuildings;
	}
	public HashMap<String, Integer> getOwnedSports() {
		return ownedSports;
	}
	public void setOwnedSports(HashMap<String, Integer> ownedSports) {
		this.ownedSports = ownedSports;
	}
	
}