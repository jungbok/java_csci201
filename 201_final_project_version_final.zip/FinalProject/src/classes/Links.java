package classes;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Links
 */
@WebServlet("/Links")
public class Links extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Links() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String type = request.getParameter("type");
		HttpSession session =  request.getSession();
		PrintWriter pw = response.getWriter();
		String p1 = "<font size=\"+1\">";
		String[] urls = {
				"<a href =\"mainScreen.jsp\">",
				"<a href =\"battle.jsp\">",
				"<a href =\"buy.jsp\">",
				"<a href =\"leaderBoard.jsp\">",
				"<a href =\"sportsScreen.jsp\">"
		};
		String[] names = {
				"My Map",
				"Battle Arena",
				"USC Store",
				"Leaderboard",
				"Sports Teams"
		};
		String end = "</font><br /><br />";
		for(int i = 0; i < urls.length; i++)
		{
			String link = session.getAttribute("location").equals(urls[i]) ?
					p1 + names[i] + end : p1 + urls[i] + names[i] + "</a>" + end;
			pw.println(link);
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
