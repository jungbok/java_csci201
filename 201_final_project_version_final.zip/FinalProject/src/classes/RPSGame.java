package classes;

import java.io.PrintWriter;

public class RPSGame {
	private int choice1;
	private int choice2;
	private RPSGameThread p1 = null;
	private RPSGameThread p2 = null;
	private boolean done = false;
	private boolean ready = false;
	private static final String rock =
	"<img src=\"https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Dwayne_Johnson_2%2C_2013.jpg/220px-Dwayne_Johnson_2%2C_2013.jpg\">";
	private static final String paper = 
	"<img src=\"https://secure.www.odcdn.com/images/us/od/storefronts/filler_graph_paper_150x150.png\">";
	private static final String scissors = 
			"<img src=\"https://i.imgur.com/fVgxCM5.jpg\">";
	String[] choices = {"rock", "paper", "scissors"};
	String[] choiceImages = {rock, paper, scissors};
	public boolean isDone()
	{
		return done;
	}
	public RPSGame()
	{
		choice1 = -1;
		choice2 = -1;
	}
	public boolean isReady()
	{
		return ready;
	}
	public void done()
	{
		done = !done;
	}
	public synchronized void setMove(int c, PrintWriter pw)
	{
		System.out.println("Setting move to " + choices[c-1]);
		if((p1 == null) || (p2 == null))
		{
			return;
		}
		if(choice1 == -1)
		{
			System.out.println("Setting move for p1");
			p1.setWriter(pw);
			choice1 = c-1;
		}
		else
		{
			System.out.println("Setting move for p2");
			p2.setWriter(pw);
			choice2 = c-1;
			checkWinner();
			p1 = null;
			p2 = null;
			choice1 = -1;
			choice2 = -1;
			ready = false;
			done = true;
		}
	}
	private int checkWinner()
	{ 
		System.out.println("Checking Winner");
		if(choice1 == choice2)
		{
			System.out.println("tie");
			sendMessage("It's a tie! <br />"
					+ "Player 1 chose " + choiceImages[choice1] + "<br />"
					+ "Player 2 chose " + choiceImages[choice2] + "<br />");
			return 0;
		}
		else if(((choice1+1) % 3) == choice2)
		{
			System.out.println("p2 win");
			p1.sendMessage("You lost! <br />");
			p2.sendMessage("You won! <br />");
			sendMessage("Player 2 wins! <br />"
					+  "Player 1 chose " + choiceImages[choice1] + "<br />"
					+ "Player 2 chose " + choiceImages[choice2] + "<br />");
			return 2;
		}
		else
		{
			System.out.println("p1 win");
			p2.sendMessage("You lost! <br />");
			p1.sendMessage("You won! <br />");
			sendMessage("Player 1 wins! <br />"
					+  "Player 1 chose " + choiceImages[choice1] + "<br />"
					+ "Player 2 chose " + choiceImages[choice2] + "<br />");
			return 1;
		}
	}
	public void addPlayer(RPSGameThread p)
	{
		if(p == null)
		{
			return;
		}
		if(p1 == null)
		{
			p1 = p;
		}
		else
		{
			p2 = p;
			p1.sendMessage("You are Player 1. <br />");
			p2.sendMessage("You are Player 2. <br />");
			sendMessage("<button type=\"button\" id=\"rockButton\""
					+ " onclick=\"sendMove(1)\" \">"
					+ rock
					+ "</button> <br />"
					+ "<button type=\"button\" id=\"paperButton\" "
					+ " onclick=\"sendMove(2)\">"
					+ paper
					+ "</button> <br />"
					+ "<button type=\"button\" id=\"scissorsButton\" "
					+ " onclick=\"sendMove(3)\">"
					+ scissors
					+ "</button> <br />");
			ready = true;
		}
	}
	public void sendMessage(String s)
	{
		p1.sendMessage(s);
		p2.sendMessage(s);
	}
	
}