package jungbokl_CSCI201L_Assignment1;

import java.util.List;

public class Parsing {
	private List<School> schools;

	public Parsing(List<School> schools) {
		this.schools = schools;
	}

	public List<School> getSchools() {
		return schools;
	}

	public void setSchools(List<School> schools) {
		this.schools = schools;
	}


}
