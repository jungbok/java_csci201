package jungbokl_CSCI201L_Assignment1;

public class Assistant {
	
	private String staffMemberID;
	
	public Assistant(String staffMemberID) {
		this.staffMemberID = staffMemberID;
	}

	public String getStaffMemberID() {
	return staffMemberID;
	}

	public void setStaffMemberID(String staffMemberID) {
	this.staffMemberID = staffMemberID;
	}

}
