package jungbokl_CSCI201L_Assignment1;

public class MeetingPeriod {

	private String day;
	private Time_ time;

	public String getDay() {
	return day;
	}

	public void setDay(String day) {
	this.day = day;
	}

	public Time_ getTime() {
	return time;
	}

	public void setTime(Time_ time) {
	this.time = time;
	}

}
